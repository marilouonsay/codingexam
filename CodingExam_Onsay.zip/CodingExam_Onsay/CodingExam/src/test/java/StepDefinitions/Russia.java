package StepDefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import Pages.CalculatorPage;
import io.cucumber.java.en.*;

public class Russia {

	WebDriver driver;
	CalculatorPage calc;

	@Given("user navigate to calculator page")
	public void user_navigate_to_calculator_page() {
		String projectPath = System.getProperty("user.dir");

		System.setProperty("webdriver.chrome.driver",projectPath+"/src/test/resources/drivers/chromedriver.exe");
		driver = new ChromeDriver();

		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);

		//accessed website
		driver.navigate().to("https://www.paysera.com/v2/en-ES/fees/currency-conversion-calculator#/");

		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);

		driver.manage().window().maximize();

		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		calc = new CalculatorPage(driver);
		
		calc.clickFlag();

		calc.clickCountry();

		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@When("user selects Russia")
	public void user_selects_Russia() {
		calc.selectRussia();
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		calc.russiaFlagIsDisplayed();
		System.out.println("==Russia is selected==");
	}
	
	@Then("Russia rates should be updated")
	public void Russia_rates_should_be_updated() {	
		calc.ratesUpdated();

		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		driver.close();
		driver.quit();
		System.out.println("==Russia rates are updated==");
	}

	@Then("^Russia currency should be (.*)$")
	public void Russia_currency_should_be_RUB(String cur) {
		calc.correctCurrencyIsDisplayed(cur);

		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		driver.close();
		driver.quit();
		System.out.println("==Russia currency is correct==");
	}
	
	@Then("Russia loss should be displayed")
	public void Russia_loss_should_be_displayed() {
		calc.lossDisplayCheck();
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		driver.close();
		driver.quit();
		System.out.println("==Russia loss is displayed==");
	}
}
