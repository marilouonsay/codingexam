package StepDefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import Pages.CalculatorPage;
import io.cucumber.java.en.*;

public class Poland {

	WebDriver driver;
	CalculatorPage calc;

	@Given("user navigate to conversion page")
	public void user_navigate_to_conversion_page() {
		String projectPath = System.getProperty("user.dir");

		System.setProperty("webdriver.chrome.driver",projectPath+"/src/test/resources/drivers/chromedriver.exe");
		driver = new ChromeDriver();

		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);

		//accessed website
		driver.navigate().to("https://www.paysera.com/v2/en-ES/fees/currency-conversion-calculator#/");

		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);

		driver.manage().window().maximize();

		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		calc = new CalculatorPage(driver);
		
		calc.clickFlag();

		calc.clickCountry();

		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@When("user selects Poland")
	public void user_selects_Poland() {
		calc.selectPoland();
				
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		calc.polandFlagIsDisplayed();
		System.out.println("==Poland is selected==");
	}
	
	@Then("Poland rates should be updated")
	public void Poland_rates_should_be_updated() {	
		calc.ratesUpdated();

		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		driver.close();
		driver.quit();
		System.out.println("==Poland rates are updated==");
	}

	@Then("^Poland currency should be (.*)$")
	public void Poland_currency_should_be_PLN(String cur) {
		calc.correctCurrencyIsDisplayed(cur);

		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		driver.close();
		driver.quit();
		System.out.println("==Poland currency is correct==");
	}
	
	@Then("Poland loss should be displayed")
	public void Poland_loss_should_be_displayed() {
		calc.lossDisplayCheck();
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		driver.close();
		driver.quit();
		System.out.println("==Poland loss are displayed==");
	}
}
