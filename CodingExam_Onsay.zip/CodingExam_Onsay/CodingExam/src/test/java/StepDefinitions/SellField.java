package StepDefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import Pages.CalculatorPage;
import io.cucumber.java.en.*;

public class SellField {
	
	WebDriver driver;
	CalculatorPage calc;

	@Given("user is in calculator page")
	public void user_is_in_calculator_page() {
		String projectPath = System.getProperty("user.dir");

		System.setProperty("webdriver.chrome.driver",projectPath+"/src/test/resources/drivers/chromedriver.exe");
		driver = new ChromeDriver();

		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
		
		driver.navigate().to("https://www.paysera.com/v2/en-ES/fees/currency-conversion-calculator#/");

		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
	}

	@When("^user inputs a (.*) in buy field$")
	public void user_inputs_a_value_in_buy_field(String value) {
		calc = new CalculatorPage(driver);
		
	    calc.buyInput(value);
	}

	@Then("sell field should be empty")
	public void sell_field_should_be_empty() {
		calc.sellEmpty();

		driver.close();
		driver.quit();
	}
}
