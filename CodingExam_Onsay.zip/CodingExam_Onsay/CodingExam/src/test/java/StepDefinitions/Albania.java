package StepDefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import Pages.CalculatorPage;
import io.cucumber.java.en.*;

public class Albania {

	WebDriver driver;
	CalculatorPage calc;

	@Given("user navigates to the conversion page")
	public void user_navigates_to_the_conversion_page() {
		String projectPath = System.getProperty("user.dir");

		System.setProperty("webdriver.chrome.driver",projectPath+"/src/test/resources/drivers/chromedriver.exe");
		driver = new ChromeDriver();

		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);

		//accessed website
		driver.navigate().to("https://www.paysera.com/v2/en-ES/fees/currency-conversion-calculator#/");

		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);

		driver.manage().window().maximize();

		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		calc = new CalculatorPage(driver);
		
		calc.clickFlag();

		calc.clickCountry();

		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@When("user selects Albania")
	public void user_selects_Albania() {
		calc.selectAlbania();
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		calc.albaniaFlagIsDisplayed();
		System.out.println("==Albania is selected==");
	}
	
	@Then("Albania rates should be updated")
	public void Albania_rates_should_be_updated() {	
		calc.ratesUpdated();

		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		driver.close();
		driver.quit();
		System.out.println("==Albania rates are updated==");
	}

	@Then("^Albania currency should be (.*)$")
	public void Albania_currency_should_be_ALL(String cur) {
		calc.correctCurrencyIsDisplayed(cur);

		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		driver.close();
		driver.quit();
		System.out.println("==Albania currency is correct==");
	}
	
	@Then("Albania loss should be displayed")
	public void Albania_loss_should_be_displayed() {
		calc.lossDisplayCheck();
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		driver.close();
		driver.quit();
		System.out.println("==Albania loss are displayed==");
	}
}
