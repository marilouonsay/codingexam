package StepDefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import Pages.CalculatorPage;
import io.cucumber.java.en.*;

public class Romania {

	WebDriver driver;
	CalculatorPage calc;

	@Given("user navigate to the calculator page")
	public void user_navigate_to_the_calculator_page() {
		String projectPath = System.getProperty("user.dir");

		System.setProperty("webdriver.chrome.driver",projectPath+"/src/test/resources/drivers/chromedriver.exe");
		driver = new ChromeDriver();

		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);

		//accessed website
		driver.navigate().to("https://www.paysera.com/v2/en-ES/fees/currency-conversion-calculator#/");

		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);

		driver.manage().window().maximize();

		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		calc = new CalculatorPage(driver);
		
		calc.clickFlag();

		calc.clickCountry();

		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@When("user selects Romania")
	public void user_selects_Romania() {
		calc.selectRomania();
				
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		calc.romaniaFlagIsDisplayed();
		System.out.println("==Romania is selected==");
	}
	
	@Then("Romania rates should be updated")
	public void Romania_rates_should_be_updated() {	
		calc.ratesUpdated();

		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		driver.close();
		driver.quit();
		System.out.println("==Romania rates are updated==");
	}

	@Then("^Romania currency should be (.*)$")
	public void Romania_currency_should_be_RON(String cur) {
		calc.correctCurrencyIsDisplayed(cur);

		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		driver.close();
		driver.quit();
		System.out.println("==Romania currency is correct==");
	}
	
	@Then("Romania loss should be displayed")
	public void Romania_loss_should_be_displayed() {
		calc.lossDisplayCheck();
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		driver.close();
		driver.quit();
		System.out.println("==Romania loss are displayed==");
	}
}
