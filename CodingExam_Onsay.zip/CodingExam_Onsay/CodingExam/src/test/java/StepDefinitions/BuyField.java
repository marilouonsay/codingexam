package StepDefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import Pages.CalculatorPage;
import io.cucumber.java.en.*;

public class BuyField {
	
	WebDriver driver;
	CalculatorPage calc;

	@Given("user goes to calculator page")
	public void user_goes_to_calculator_page() {
		String projectPath = System.getProperty("user.dir");

		System.setProperty("webdriver.chrome.driver",projectPath+"/src/test/resources/drivers/chromedriver.exe");
		driver = new ChromeDriver();

		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
		
		driver.navigate().to("https://www.paysera.com/v2/en-ES/fees/currency-conversion-calculator#/");

		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
	}

	@When("^user inputs a (.*) in sell field$")
	public void user_inputs_a_value_in_sell_field(String value) {
		calc = new CalculatorPage(driver);
		
	    calc.sellInput(value);
	}

	@Then("buy field should be empty")
	public void buy_field_should_be_empty() {
		calc.buyEmpty();

		driver.close();
		driver.quit();
	}
}
