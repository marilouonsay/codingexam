package Pages;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;

public class CalculatorPage {

	WebDriver driver;

	By txt_sell = By.xpath("//body/main[1]/article[1]/section[3]/div[1]/div[3]/div[1]/div[1]/div[2]/div[1]/form[1]/div[1]/input[1]");
	By txt_buy = By.xpath("//body/main[1]/article[1]/section[3]/div[1]/div[3]/div[1]/div[1]/div[2]/div[1]/form[1]/div[3]/input[1]");
	By drp_countryLanguage = By.xpath("//body/footer[1]/div[2]/div[1]/div[1]/div[2]/div[1]/span[1]");
	By drp_country = By.xpath("//button[@id='countries-dropdown']");
	By img_loader = By.xpath("//body/main[1]/article[1]/section[3]/div[1]/div[3]/div[1]/div[1]/div[2]/div[2]/img[1]");
	By tbl_row = By.xpath("//table[@class='transformable-table table table-striped']/tbody/tr");
	By tbl_column = By.xpath("//table[@class='transformable-table table table-striped']/tbody/tr[1]/*");
	By img_lithuania = By.xpath("//body/footer[1]/div[2]/div[1]/div[1]/div[2]/div[1]/span[1]/span[@class='flag-icon-small flag-icon-lt']");
	By img_latvia = By.xpath("//body/footer[1]/div[2]/div[1]/div[1]/div[2]/div[1]/span[1]/span[@class='flag-icon-small flag-icon-lv']");
	By img_estonia = By.xpath("//body/footer[1]/div[2]/div[1]/div[1]/div[2]/div[1]/span[1]/span[@class='flag-icon-small flag-icon-ee']");
	By img_bulgaria = By.xpath("//body/footer[1]/div[2]/div[1]/div[1]/div[2]/div[1]/span[1]/span[@class='flag-icon-small flag-icon-bg']");
	By img_spain = By.xpath("//body/footer[1]/div[2]/div[1]/div[1]/div[2]/div[1]/span[1]/span[@class='flag-icon-small flag-icon-es']");
	By img_romania = By.xpath("//body/footer[1]/div[2]/div[1]/div[1]/div[2]/div[1]/span[1]/span[@class='flag-icon-small flag-icon-ro']");
	By img_poland = By.xpath("//body/footer[1]/div[2]/div[1]/div[1]/div[2]/div[1]/span[1]/span[@class='flag-icon-small flag-icon-pl']");
	By img_uk = By.xpath("//body/footer[1]/div[2]/div[1]/div[1]/div[2]/div[1]/span[1]/span[@class='flag-icon-small flag-icon-gb']");
	By img_germany = By.xpath("//body/footer[1]/div[2]/div[1]/div[1]/div[2]/div[1]/span[1]/span[@class='flag-icon-small flag-icon-de']");
	By img_russia = By.xpath("//body/footer[1]/div[2]/div[1]/div[1]/div[2]/div[1]/span[1]/span[@class='flag-icon-small flag-icon-ru']");
	By img_algeria = By.xpath("//body/footer[1]/div[2]/div[1]/div[1]/div[2]/div[1]/span[1]/span[@class='flag-icon-small flag-icon-dz']");
	By img_albania = By.xpath("//body/footer[1]/div[2]/div[1]/div[1]/div[2]/div[1]/span[1]/span[@class='flag-icon-small flag-icon-al']");
	By img_kosovo = By.xpath("//body/footer[1]/div[2]/div[1]/div[1]/div[2]/div[1]/span[1]/span[@class='flag-icon-small flag-icon-xk']");
	By img_ukraine = By.xpath("//body/footer[1]/div[2]/div[1]/div[1]/div[2]/div[1]/span[1]/span[@class='flag-icon-small flag-icon-ua']");
	By img_anotherCountry = By.xpath("//body/footer[1]/div[2]/div[1]/div[1]/div[2]/div[1]/span[1]/span[@class='glyphicon glyphicon-globe']");

	public CalculatorPage(WebDriver driver){
		this.driver = driver;
	}

	public void sellInput(String value) {	
		driver.findElement(txt_sell).clear();
		driver.findElement(txt_sell).sendKeys(value);		
	}

	public void buyInput(String value) {	
		driver.findElement(txt_buy).clear();
		driver.findElement(txt_buy).sendKeys(value);		
	}

	public void sellEmpty() {	
		driver.findElement(txt_sell).equals(null);
	}

	public void buyEmpty() {	
		driver.findElement(txt_buy).equals(null);
	}

	public void clickFlag() {	
		driver.findElement(drp_countryLanguage).click();
	}

	public void clickCountry() {	
		driver.findElement(drp_country).click();
	}

	public void selectLithuania() {		
		driver.findElement(drp_country).sendKeys(Keys.ARROW_DOWN, Keys.ENTER);
	}

	public void selectLatvia() {		
		driver.findElement(drp_country).sendKeys(Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ENTER);
	}

	public void selectEstonia() {		
		driver.findElement(drp_country).sendKeys(Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ENTER);
	}

	public void selectBulgaria() {	
		driver.findElement(drp_country).sendKeys(Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ENTER);
	}

	public void selectSpain() {	
		driver.findElement(drp_country).sendKeys(Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ENTER);
	}

	public void selectRomania() {	
		driver.findElement(drp_country).sendKeys(Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ENTER);
	}

	public void selectPoland() {	
		driver.findElement(drp_country).sendKeys(Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ENTER);
	}

	public void selectUK() {	
		driver.findElement(drp_country).sendKeys(Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ENTER);
	}

	public void selectGermany() {	
		driver.findElement(drp_country).sendKeys(Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ENTER);
	}

	public void selectRussia() {	
		driver.findElement(drp_country).sendKeys(Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ENTER);
	}

	public void selectAlgeria() {	
		driver.findElement(drp_country).sendKeys(Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ENTER);
	}

	public void selectAlbania() {	
		driver.findElement(drp_country).sendKeys(Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ENTER);
	}

	public void selectKosovo() {	
		driver.findElement(drp_country).sendKeys(Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ENTER);
	}

	public void selectUkraine() {	
		driver.findElement(drp_country).sendKeys(Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ENTER);
	}

	public void selectAnotherCountry() {	
		driver.findElement(drp_country).sendKeys(Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ARROW_DOWN, Keys.ENTER);
	}

	public void correctCurrencyIsDisplayed(String currency) {	
		try {
			System.out.println("Currency is: "+currency);
			driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//form/div/div/div/span/span/span[text()[contains(.,'" + currency + "')]]")).isDisplayed();
			driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		} catch (NoSuchElementException e) {
			System.out.println("XXTable did not load properlyXX");
			driver.quit();
			Assert.fail();	
		}
	}

	public void ratesUpdated() {	
		try {
			driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			driver.findElement(img_loader).isDisplayed();
			driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		} catch (NoSuchElementException e) {
			System.out.println("XXTable did not load properlyXX");
			driver.quit();
			Assert.fail();	
		}
	}

	public void lithuaniaFlagIsDisplayed() {	
		driver.findElement(img_lithuania).isDisplayed();
	}

	public void latviaFlagIsDisplayed() {	
		driver.findElement(img_latvia).isDisplayed();
	}

	public void estoniaFlagIsDisplayed() {	
		driver.findElement(img_estonia).isDisplayed();
	}

	public void bulgariaFlagIsDisplayed() {	
		driver.findElement(img_bulgaria).isDisplayed();
	}

	public void spainFlagIsDisplayed() {	
		driver.findElement(img_spain).isDisplayed();
	}

	public void romaniaFlagIsDisplayed() {	
		driver.findElement(img_romania).isDisplayed();
	}

	public void polandFlagIsDisplayed() {	
		driver.findElement(img_poland).isDisplayed();
	}

	public void ukFlagIsDisplayed() {	
		driver.findElement(img_uk).isDisplayed();
	}

	public void germanyFlagIsDisplayed() {	
		driver.findElement(img_germany).isDisplayed();
	}

	public void russiaFlagIsDisplayed() {	
		driver.findElement(img_russia).isDisplayed();
	}

	public void algeriaFlagIsDisplayed() {	
		driver.findElement(img_algeria).isDisplayed();
	}

	public void albaniaFlagIsDisplayed() {	
		driver.findElement(img_albania).isDisplayed();
	}

	public void kosovoFlagIsDisplayed() {	
		driver.findElement(img_kosovo).isDisplayed();
	}

	public void ukraineFlagIsDisplayed() {	
		driver.findElement(img_ukraine).isDisplayed();
	}

	public void anotherCountryFlagIsDisplayed() {	
		driver.findElement(img_anotherCountry).isDisplayed();
	}


	public void lossDisplayCheck() {
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		int rowCount = driver.findElements(tbl_row).size();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		System.out.println("Row size is: "+rowCount);
		
		if (rowCount == 0) {
			System.out.println("XXTable did not load properlyXX");
			driver.quit();
			Assert.fail();	
		}

		int columnCount = driver.findElements(tbl_column).size();
		System.out.println("Column size is: "+columnCount);

		if (columnCount > 4) {
			for(int i = 1; i <= rowCount; i++) {
				driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
				String payseraAmount = (driver.findElement(By.xpath("//table[@class='transformable-table table table-striped']/tbody/tr[" + i + "]/td[4]")).getText());			

				for(int k = 5; k <= columnCount; k++) {
					String bankAmount;

					try {
						driver.manage().timeouts().implicitlyWait(0, TimeUnit.MILLISECONDS);
						bankAmount = (driver.findElement(By.xpath("//table[@class='transformable-table table table-striped']/tbody/tr[" + i + "]/td[" + k + "]/span/span/span")).getText());			
						driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
					} catch (NoSuchElementException e) {
						bankAmount = payseraAmount;
					}

					double x = Double.parseDouble(bankAmount.replace(",",""));
					double y = Double.parseDouble(payseraAmount.replace(",",""));
					double z = x - y;

					System.out.println("[" + i + "][" + k + "] Diff is: "+z);

					if (z < 0) {	
						try {
							driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
							driver.findElement(By.xpath("//table[@class='transformable-table table table-striped']/tbody/tr[" + i + "]/td[" + k + "]/span/span/span[2]")).isDisplayed();			
						} catch (NoSuchElementException e) {
							System.out.println("Bug found in: [" + i + "][" + k + "] Diff is "+z+" but no loss is displayed.");
							driver.quit();
							Assert.fail();
						}
					} 

				}
			}
		}
	}
}
