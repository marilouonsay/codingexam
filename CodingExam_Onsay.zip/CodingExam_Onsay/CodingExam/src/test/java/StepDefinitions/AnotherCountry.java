package StepDefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import Pages.CalculatorPage;
import io.cucumber.java.en.*;

public class AnotherCountry {

	WebDriver driver;
	CalculatorPage calc;

	@Given("user navigated to the conversion page")
	public void user_navigated_to_the_conversion_page() {
		String projectPath = System.getProperty("user.dir");

		System.setProperty("webdriver.chrome.driver",projectPath+"/src/test/resources/drivers/chromedriver.exe");
		driver = new ChromeDriver();

		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);

		//accessed website
		driver.navigate().to("https://www.paysera.com/v2/en-ES/fees/currency-conversion-calculator#/");

		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);

		driver.manage().window().maximize();

		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		calc = new CalculatorPage(driver);
		
		calc.clickFlag();

		calc.clickCountry();

		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@When("user selects Another Country")
	public void user_selects_Another_Country() {
		calc.selectAnotherCountry();
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	

		calc.anotherCountryFlagIsDisplayed();
		System.out.println("==AnotherCountry is selected==");
	}
	
	@Then("Another Country rates should be updated")
	public void Another_Country_rates_should_be_updated() {	
		calc.ratesUpdated();

		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		driver.close();
		driver.quit();
		System.out.println("==Another Country rates are displayed==");
	}

	@Then("^Another Country currency should be (.*)$")
	public void Another_Country_currency_should_be_EUR(String cur) {
		calc.correctCurrencyIsDisplayed(cur);

		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		driver.close();
		driver.quit();
		System.out.println("==Another Country currency is correct==");
	}
	
	@Then("Another Country loss should be displayed")
	public void Another_Country_loss_should_be_displayed() {
		calc.lossDisplayCheck();
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		driver.close();
		driver.quit();
		System.out.println("==Another Country loss is displayed==");
	}
}
