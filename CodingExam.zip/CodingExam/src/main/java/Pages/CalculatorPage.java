package Pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CalculatorPage {

	WebDriver driver;

	By txt_sell = By.xpath("//label[text()='Sell']//following-sibling::input[@type='text']");
	By txt_buy = By.xpath("//label[text()='Buy']//following-sibling::input[@type='text']");
	By drp_countryLanguage = By.xpath("//span[@class='dropup']");
	By drp_country = By.id("countries-dropdown");
	By img_loader = By.xpath("//table[starts-with(@class,'transformable')]//following-sibling::div/img[contains(@class,'lazyloaded')]");
	By tbl_row = By.xpath("//tbody/tr");
	By tbl_column = By.xpath("//tr[1]/td");
	By img_anotherCountry = By.xpath("//span[contains(@class,'glyphicon-globe')]//following-sibling::span[@class='dropup']");
	By drp_lithuania = By.xpath("//ul[@class='dropdown-menu']//descendant::span[contains(@class,'flag-icon-lt')]");
	By drp_latvia = By.xpath("//ul[@class='dropdown-menu']//descendant::span[contains(@class,'flag-icon-lv')]");
	By drp_estonia = By.xpath("//ul[@class='dropdown-menu']//descendant::span[contains(@class,'flag-icon-ee')]");
	By drp_bulgaria = By.xpath("//ul[@class='dropdown-menu']//descendant::span[contains(@class,'flag-icon-bg')]");
	By drp_spain = By.xpath("//ul[@class='dropdown-menu']//descendant::span[contains(@class,'flag-icon-es')]");
	By drp_romania = By.xpath("//ul[@class='dropdown-menu']//descendant::span[contains(@class,'flag-icon-ro')]");
	By drp_poland = By.xpath("//ul[@class='dropdown-menu']//descendant::span[contains(@class,'flag-icon-pl')]");
	By drp_uk = By.xpath("//ul[@class='dropdown-menu']//descendant::span[contains(@class,'flag-icon-gb')]");
	By drp_germany = By.xpath("//ul[@class='dropdown-menu']//descendant::span[contains(@class,'flag-icon-de')]");
	By drp_russia = By.xpath("//ul[@class='dropdown-menu']//descendant::span[contains(@class,'flag-icon-ru')]");
	By drp_algeria = By.xpath("//ul[@class='dropdown-menu']//descendant::span[contains(@class,'flag-icon-dz')]");
	By drp_albania = By.xpath("//ul[@class='dropdown-menu']//descendant::span[contains(@class,'flag-icon-al')]");
	By drp_kosovo = By.xpath("//ul[@class='dropdown-menu']//descendant::span[contains(@class,'flag-icon-xk')]");
	By drp_ukraine = By.xpath("//ul[@class='dropdown-menu']//descendant::span[contains(@class,'flag-icon-ua')]");
	By drp_anotherCountry = By.xpath("//ul[@class='dropdown-menu']//descendant::a[contains(text(),'Another country')]");
	By txt_currency = By.xpath("//label[text()='Sell']//following-sibling::div//span[@data-ng-bind='$select.selected']");

	public CalculatorPage(WebDriver driver){
		this.driver = driver;
	}

	public void sellInput(String value) {	
		WebDriverWait wait = new WebDriverWait(driver,15);

		wait.until(ExpectedConditions.visibilityOfElementLocated(txt_sell));
		driver.findElement(txt_sell).clear();
		driver.findElement(txt_sell).sendKeys(value);		
	}

	public void buyInput(String value) {	
		WebDriverWait wait = new WebDriverWait(driver,15);

		wait.until(ExpectedConditions.visibilityOfElementLocated(txt_buy));
		driver.findElement(txt_buy).clear();
		driver.findElement(txt_buy).sendKeys(value);		
	}

	public boolean sellEmpty() {	
		driver.findElement(txt_sell).equals(null);
		return true;
	}

	public boolean buyEmpty() {	
		driver.findElement(txt_buy).equals(null);
		return true;
	}

	public void clickFlag() {	
		driver.findElement(drp_countryLanguage).click();
	}

	public void clickCountry() {	
		driver.findElement(drp_country).click();
	}

	public void selectCountry(String country) {
		switch(country) {
		case "albania":
			driver.findElement(drp_albania).click();
			break;
		case "algeria":
			driver.findElement(drp_algeria).click();
			break;
		case "anotherCountry":
			driver.findElement(drp_anotherCountry).click();
			break;
		case "bulgaria":
			driver.findElement(drp_bulgaria).click();
			break;
		case "estonia":
			driver.findElement(drp_estonia).click();
			break;
		case "germany":
			driver.findElement(drp_germany).click();
			break;
		case "kosovo":
			driver.findElement(drp_kosovo).click();
			break;
		case "latvia":
			driver.findElement(drp_latvia).click();
			break;
		case "lithuania":
			driver.findElement(drp_lithuania).click();
			break;
		case "poland":
			driver.findElement(drp_poland).click();
			break;
		case "romania":
			driver.findElement(drp_romania).click();
			break;
		case "russia":
			driver.findElement(drp_russia).click();
			break;
		case "spain":
			driver.findElement(drp_spain).click();
			break;
		case "uk":
			driver.findElement(drp_uk).click();
			break;
		case "ukraine":
			driver.findElement(drp_ukraine).click();
			break;
		default:
			System.out.println("no match");
		}
	}

	public boolean correctCurrencyIsDisplayed(String currency) {	
		WebDriverWait wait = new WebDriverWait(driver,15);
		wait.until(ExpectedConditions.visibilityOfElementLocated(txt_currency));
		String cur = driver.findElement(txt_currency).getText();
		if (cur.equalsIgnoreCase(currency)) {
			return true;
		}
		else {
			System.out.println("XXIncorrect currencyXX");
			return false;
		}
	}

	public boolean ratesAreUpdated() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
		if (driver.findElement(img_loader).isDisplayed()) {
			return true;
		}
		else {
			System.out.println("XXTable did not load properlyXX");
			return false;
		}
	}


	public boolean lossDisplayCheck() {
		WebDriverWait wait = new WebDriverWait(driver,15);

		wait.until(ExpectedConditions.visibilityOfElementLocated(tbl_row));

		int rowCount = driver.findElements(tbl_row).size();
		int columnCount = driver.findElements(tbl_column).size();

		System.out.println("[" + rowCount + "][" + columnCount + "]");

		String startPath = "//tbody/tr[";
		String midPath = "]/td[";
		String endPath = "]//descendant::span[@class='ng-binding']";

		if (columnCount == 4) {
			return true;
		} else if (columnCount > 4) {
			for(int i = 1; i <= rowCount; i++) {

				String payseraPath = startPath + i + midPath + 4 + endPath;
				String payseraAmount = driver.findElement(By.xpath(payseraPath)).getText();

				System.out.println("[" + rowCount + "][" + payseraAmount + "]");
				for(int k = 5; k <= columnCount; k++) {
					String bankAmount;

					try {
						String bankPath = startPath + i + midPath + k + endPath;
						bankAmount = driver.findElement(By.xpath(bankPath)).getText();
					} catch (NoSuchElementException e) {
						//if dash instead of number is displayed
						bankAmount = payseraAmount;
					}

					double x = Double.parseDouble(bankAmount.replace(",",""));
					double y = Double.parseDouble(payseraAmount.replace(",",""));
					double z = x - y;

					System.out.println("[" + i + "][" + k + "] Diff is: "+z);

					String lossEndPath = "]//descendant::span[contains(@class,'other-bank-loss')]";
					String lossPath = startPath + i + midPath + k + lossEndPath;

					if (z < 0) {						
						try {
							driver.findElement(By.xpath(lossPath)).isDisplayed();
						} catch (NoSuchElementException e) {
							System.out.println("Bug in [" + i + "][" + k + "]: Diff is: "+z);
							return false;
						}
					}
				}
			}
			return true;
		} else {
			System.out.println("XXTable did not load properlyXX");
			return false;
		}
	}
}
