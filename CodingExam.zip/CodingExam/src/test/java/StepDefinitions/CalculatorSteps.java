package StepDefinitions;

import Factory.DriverFactory;
import Pages.CalculatorPage;
import io.cucumber.java.en.*;
import org.junit.Assert;

public class CalculatorSteps {

	public static String url = null;
	private CalculatorPage calc = new CalculatorPage(DriverFactory.getDriver());

	@Given("user navigates to the conversion page")
	public void user_navigates_to_the_conversion_page() {
		DriverFactory.getDriver().get(url);		
	}

	@When("^user selects (.*)$")
	public void user_selects_country(String country) {
		calc.clickFlag();
		calc.clickCountry();
		calc.selectCountry(country);
		System.out.println("=="+country+" is selected==");
	}

	@Then("rates should be updated")
	public void Albania_rates_should_be_updated() {	
		Assert.assertEquals(true, calc.ratesAreUpdated());
	}

	@Then("^currency should be (.*)$")
	public void currency_should_be_ALL(String cur) {
		Assert.assertEquals(true, calc.correctCurrencyIsDisplayed(cur));
	}

	@Then("loss should be displayed")
	public void loss_should_be_displayed() {
		Assert.assertEquals(true, calc.lossDisplayCheck());
	}

	@When("^user inputs (.*) in sell field$")
	public void user_inputs_value_in_sell_field(String value) {
		calc.sellInput(value);
	}

	@Then("buy field should be empty")
	public void buy_field_should_be_empty() {
		Assert.assertEquals(true, calc.buyEmpty());
	}

	@When("^user inputs (.*) in buy field$")
	public void user_inputs_value_in_buy_field(String value) {
		calc.sellInput(value);
	}

	@Then("sell field should be empty")
	public void sell_field_should_be_empty() {
		Assert.assertEquals(true, calc.buyEmpty());
	}
}
